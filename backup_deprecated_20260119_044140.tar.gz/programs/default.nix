{
  imports = [
    ./browsers.nix
    ./common.nix
    ./git.nix
    ./media.nix
    ./xdg.nix
    ./networking.nix
    ./gaming.nix
    ./productivity.nix
    ./devtools.nix
  ];
}
